<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'life-blogs/home/Home';
$route['index'] = 'life-blogs/home/Home';